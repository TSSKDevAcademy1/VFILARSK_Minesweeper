
public class Triangle {

	private int size;
	
	public Triangle(){
		
	}
	
	public void setSize(int size){
		this.size = size;
	}
	
	public int getSize(int size){
		return this.size;
	}
}
